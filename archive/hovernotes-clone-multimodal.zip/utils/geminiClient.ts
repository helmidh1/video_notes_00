import { GoogleGenAI } from '@google/genai';
import type { TranscriptSegment } from './messaging';

const API_KEY_STORAGE_KEY = 'gemini_api_key';

export async function saveGeminiApiKey(apiKey: string): Promise<void> {
  await chrome.storage.local.set({ [API_KEY_STORAGE_KEY]: apiKey.trim() });
}

export async function getGeminiApiKey(): Promise<string> {
  const result = await chrome.storage.local.get(API_KEY_STORAGE_KEY);
  return (result[API_KEY_STORAGE_KEY] as string) || '';
}

export async function summarizeTranscriptToMarkdown(params: {
  apiKey: string;
  pageTitle: string;
  pageUrl: string;
  segments: TranscriptSegment[];
}): Promise<string> {
  const { apiKey, pageTitle, pageUrl, segments } = params;

  const ai = new GoogleGenAI({ apiKey });

  const formattedTranscript = segments
    .map((s) => `[${s.formattedTime} | ${Math.floor(s.startTime)}s] ${s.text}`)
    .join('\n');

  const prompt = `
You are a technical note-taking assistant. Convert the following video transcript into structured, concise Obsidian Markdown study notes.

Video Title: ${pageTitle}
Video URL: ${pageUrl}

Requirements:
1. Start with a 2-3 sentence Overview section.
2. Group key topics under ## headings.
3. Include clickable Markdown timestamp links in the format [MM:SS](${pageUrl}#t=SECONDSs) next to important points using the exact SECONDS value from the transcript lines.
4. Extract any code snippets, formulas, or key definitions into fenced blocks or callouts.

Transcript:
${formattedTranscript}
`.trim();

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });

  return response.text || 'No summary generated.';
}

export async function analyzeVideoFrameWithGemini(params: {
  apiKey: string;
  dataUrl: string;
  formattedTime: string;
  pageTitle: string;
}): Promise<string> {
  const { apiKey, dataUrl, formattedTime, pageTitle } = params;
  const ai = new GoogleGenAI({ apiKey });

  const [header, base64Data] = dataUrl.split(',');
  const mimeMatch = header?.match(/data:(.*?);base64/);
  const mimeType = mimeMatch ? mimeMatch[1] : 'image/webp';

  const prompt = `
You are a technical study assistant analyzing a video frame captured at ${formattedTime} from "${pageTitle}".

Requirements:
1. Explain any diagrams, architecture charts, slides, mathematical formulas, or source code visible on the screen.
2. If source code is shown, transcribe the key block into a fenced Markdown code block.
3. Keep the explanation concise and formatted for an Obsidian Markdown note.
`.trim();

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: [
      {
        inlineData: {
          mimeType,
          data: base64Data,
        },
      },
      prompt,
    ],
  });

  return response.text || 'No visual analysis returned.';
}
