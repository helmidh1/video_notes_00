export type ExtensionMessage =
  | { type: 'CAPTURE_VIDEO_FRAME' }
  | { type: 'SEEK_VIDEO'; timestamp: number }
  | { type: 'EXTRACT_TRANSCRIPT' };

export interface FrameCaptureResponse {
  ok: boolean;
  timestamp: number;
  formattedTime: string;
  dataUrl?: string;
  pageTitle?: string;
  pageUrl?: string;
  error?: string;
}

export interface TranscriptSegment {
  startTime: number;
  formattedTime: string;
  text: string;
}

export interface TranscriptResponse {
  ok: boolean;
  segments: TranscriptSegment[];
  pageTitle?: string;
  pageUrl?: string;
  error?: string;
}
