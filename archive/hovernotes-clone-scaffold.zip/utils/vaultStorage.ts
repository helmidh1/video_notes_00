import { get, set } from 'idb-keyval';

const VAULT_HANDLE_KEY = 'obsidian_vault_handle';

export async function selectVaultDirectory(): Promise<FileSystemDirectoryHandle> {
  const handle = await window.showDirectoryPicker({ mode: 'readwrite' });
  await set(VAULT_HANDLE_KEY, handle);
  return handle;
}

export async function getSavedVaultDirectory(): Promise<FileSystemDirectoryHandle | null> {
  const handle = await get<FileSystemDirectoryHandle>(VAULT_HANDLE_KEY);
  if (!handle) return null;

  const permission = await handle.queryPermission({ mode: 'readwrite' });
  if (permission === 'granted') return handle;

  const requested = await handle.requestPermission({ mode: 'readwrite' });
  return requested === 'granted' ? handle : null;
}

function dataUrlToUint8Array(dataUrl: string): Uint8Array {
  const base64 = dataUrl.split(',')[1];
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function saveBinaryAttachment(
  dirHandle: FileSystemDirectoryHandle,
  fileName: string,
  dataUrl: string
): Promise<void> {
  const assetsDir = await dirHandle.getDirectoryHandle('attachments', { create: true });
  const fileHandle = await assetsDir.getFileHandle(fileName, { create: true });
  const writable = await fileHandle.createWritable();
  await writable.write(dataUrlToUint8Array(dataUrl));
  await writable.close();
}

export async function saveMarkdownFile(
  dirHandle: FileSystemDirectoryHandle,
  fileName: string,
  markdownContent: string
): Promise<void> {
  const safeName = fileName.replace(/[<>:"/\\|?*]+/g, '-').trim() || 'Video-Note';
  const fileHandle = await dirHandle.getFileHandle(`${safeName}.md`, { create: true });
  const writable = await fileHandle.createWritable();
  await writable.write(markdownContent);
  await writable.close();
}
