import { defineConfig } from 'wxt';

export default defineConfig({
  modules: ['@wxt-dev/module-react'],
  manifest: {
    name: 'HoverNotes Clone',
    description: 'Capture video frames, timestamps, and Markdown notes to a local folder.',
    version: '0.1.0',
    permissions: ['sidePanel', 'storage', 'activeTab', 'scripting'],
    action: {
      default_title: 'Open Notes Side Panel',
    },
  },
});
