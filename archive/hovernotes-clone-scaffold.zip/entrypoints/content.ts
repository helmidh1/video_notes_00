import type { ExtensionMessage, FrameCaptureResponse } from '../utils/messaging';
import { extractVideoTranscript, formatSeconds } from '../utils/transcriptExtractor';

function getActiveVideo(): HTMLVideoElement | undefined {
  const videos = Array.from(document.querySelectorAll('video'));
  return videos.find((v) => v.readyState >= 2 && v.videoWidth > 0) || videos[0];
}

function captureActiveVideoFrame(): FrameCaptureResponse {
  const video = getActiveVideo();

  if (!video) {
    return {
      ok: false,
      timestamp: 0,
      formattedTime: '00:00',
      error: 'No active HTML5 video element found on this page.',
    };
  }

  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth || 1280;
  canvas.height = video.videoHeight || 720;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return {
      ok: false,
      timestamp: video.currentTime,
      formattedTime: formatSeconds(video.currentTime),
      error: 'Canvas 2D context is unavailable.',
    };
  }

  try {
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/webp', 0.85);

    return {
      ok: true,
      timestamp: video.currentTime,
      formattedTime: formatSeconds(video.currentTime),
      dataUrl,
      pageTitle: document.title,
      pageUrl: window.location.href,
    };
  } catch (err) {
    return {
      ok: false,
      timestamp: video.currentTime,
      formattedTime: formatSeconds(video.currentTime),
      error: err instanceof Error ? err.message : 'Cross-origin canvas capture failed.',
    };
  }
}

export default defineContentScript({
  matches: ['*://*/*'],
  main() {
    chrome.runtime.onMessage.addListener(
      (message: ExtensionMessage, _sender, sendResponse) => {
        if (message.type === 'CAPTURE_VIDEO_FRAME') {
          sendResponse(captureActiveVideoFrame());
          return true;
        }

        if (message.type === 'EXTRACT_TRANSCRIPT') {
          const video = getActiveVideo();
          sendResponse(extractVideoTranscript(video));
          return true;
        }

        if (message.type === 'SEEK_VIDEO') {
          const video = getActiveVideo();
          if (video) {
            video.currentTime = message.timestamp;
            sendResponse({ ok: true });
          } else {
            sendResponse({ ok: false, error: 'No video found to seek.' });
          }
          return true;
        }

        return false;
      }
    );
  },
});
