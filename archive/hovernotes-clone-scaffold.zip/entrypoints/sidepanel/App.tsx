import React, { useEffect, useState } from 'react';
import type {
  ExtensionMessage,
  FrameCaptureResponse,
  TranscriptResponse,
} from '../../utils/messaging';
import {
  getSavedVaultDirectory,
  saveBinaryAttachment,
  saveMarkdownFile,
  selectVaultDirectory,
} from '../../utils/vaultStorage';
import {
  getGeminiApiKey,
  saveGeminiApiKey,
  summarizeTranscriptToMarkdown,
} from '../../utils/geminiClient';

interface CapturedFrame {
  id: string;
  fileName: string;
  formattedTime: string;
  timestamp: number;
  dataUrl: string;
}

export default function App() {
  const [apiKey, setApiKey] = useState('');
  const [noteTitle, setNoteTitle] = useState('Video Notes');
  const [markdown, setMarkdown] = useState('');
  const [frames, setFrames] = useState<CapturedFrame[]>([]);
  const [vaultName, setVaultName] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [status, setStatus] = useState<string>('');

  useEffect(() => {
    getGeminiApiKey().then((savedKey) => {
      if (savedKey) setApiKey(savedKey);
    });
  }, []);

  async function handleApiKeyChange(value: string) {
    setApiKey(value);
    await saveGeminiApiKey(value);
  }

  async function handleConnectVault() {
    try {
      const handle = await selectVaultDirectory();
      setVaultName(handle.name);
      setStatus(`Connected to folder: ${handle.name}`);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : 'Folder selection canceled.');
    }
  }

  async function handleCaptureFrame() {
    setStatus('Capturing frame...');
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.id) {
      setStatus('No active browser tab found.');
      return;
    }

    try {
      const response = await chrome.tabs.sendMessage<ExtensionMessage, FrameCaptureResponse>(
        tab.id,
        { type: 'CAPTURE_VIDEO_FRAME' }
      );

      if (!response?.ok || !response.dataUrl) {
        setStatus(response?.error || 'Failed to capture video frame.');
        return;
      }

      const fileName = `frame-${Date.now()}.webp`;
      const newFrame: CapturedFrame = {
        id: crypto.randomUUID(),
        fileName,
        formattedTime: response.formattedTime,
        timestamp: response.timestamp,
        dataUrl: response.dataUrl,
      };

      if (response.pageTitle && noteTitle === 'Video Notes') {
        setNoteTitle(response.pageTitle);
      }

      setFrames((prev) => [...prev, newFrame]);
      const snippet = `\n### [${response.formattedTime}](${response.pageUrl}#t=${Math.floor(
        response.timestamp
      )}s)\n![[${fileName}]]\n\n`;
      setMarkdown((prev) => prev + snippet);
      setStatus(`Captured frame at ${response.formattedTime}`);
    } catch {
      setStatus('Content script not ready. Refresh the video tab and try again.');
    }
  }

  async function handleSummarizeTranscript() {
    if (!apiKey.trim()) {
      setStatus('Enter your Gemini API key first.');
      return;
    }

    setIsSummarizing(true);
    setStatus('Extracting video captions...');

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      setIsSummarizing(false);
      setStatus('No active browser tab found.');
      return;
    }

    try {
      const response = await chrome.tabs.sendMessage<ExtensionMessage, TranscriptResponse>(
        tab.id,
        { type: 'EXTRACT_TRANSCRIPT' }
      );

      if (!response?.ok || response.segments.length === 0) {
        setIsSummarizing(false);
        setStatus(response?.error || 'Could not extract transcript.');
        return;
      }

      if (response.pageTitle && noteTitle === 'Video Notes') {
        setNoteTitle(response.pageTitle);
      }

      setStatus(
        `Summarizing ${response.segments.length} caption segments with Gemini...`
      );

      const summaryMarkdown = await summarizeTranscriptToMarkdown({
        apiKey,
        pageTitle: response.pageTitle || noteTitle,
        pageUrl: response.pageUrl || tab.url || '',
        segments: response.segments,
      });

      setMarkdown((prev) =>
        prev ? `${prev}\n\n---\n\n${summaryMarkdown}` : summaryMarkdown
      );
      setStatus('Transcript summary added to notes.');
    } catch (err) {
      setStatus(
        err instanceof Error ? err.message : 'Failed to summarize transcript.'
      );
    } finally {
      setIsSummarizing(false);
    }
  }

  async function handleSeek(timestamp: number) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    await chrome.tabs.sendMessage<ExtensionMessage>(tab.id, {
      type: 'SEEK_VIDEO',
      timestamp,
    });
  }

  async function handleExportToVault() {
    try {
      const dirHandle =
        (await getSavedVaultDirectory()) || (await selectVaultDirectory());
      setVaultName(dirHandle.name);

      for (const frame of frames) {
        await saveBinaryAttachment(dirHandle, frame.fileName, frame.dataUrl);
      }

      const frontmatter = `---\ntitle: "${noteTitle}"\ncreated: "${new Date().toISOString()}"\n---\n\n`;
      await saveMarkdownFile(dirHandle, noteTitle, frontmatter + markdown);
      setStatus(
        `Saved "${noteTitle}.md" and ${frames.length} image(s) to ${dirHandle.name}.`
      );
    } catch (err) {
      setStatus(err instanceof Error ? err.message : 'Failed to save to local folder.');
    }
  }

  return (
    <div style={{ padding: '12px', fontFamily: 'system-ui, sans-serif' }}>
      <input
        type="password"
        value={apiKey}
        onChange={(e) => handleApiKeyChange(e.target.value)}
        placeholder="Gemini API Key (saved locally)"
        style={{
          width: '100%',
          marginBottom: '8px',
          padding: '6px',
          boxSizing: 'border-box',
        }}
      />

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '12px' }}>
        <button onClick={handleConnectVault}>
          {vaultName ? `Vault: ${vaultName}` : 'Select Local Vault'}
        </button>
        <button onClick={handleCaptureFrame}>Capture Frame</button>
        <button onClick={handleSummarizeTranscript} disabled={isSummarizing}>
          {isSummarizing ? 'Summarizing...' : 'Summarize Transcript'}
        </button>
        <button onClick={handleExportToVault}>Save to Vault</button>
      </div>

      <input
        type="text"
        value={noteTitle}
        onChange={(e) => setNoteTitle(e.target.value)}
        placeholder="Note Title"
        style={{
          width: '100%',
          marginBottom: '8px',
          padding: '6px',
          boxSizing: 'border-box',
        }}
      />

      <textarea
        value={markdown}
        onChange={(e) => setMarkdown(e.target.value)}
        placeholder="Markdown notes and timestamps..."
        rows={14}
        style={{
          width: '100%',
          marginBottom: '12px',
          padding: '6px',
          boxSizing: 'border-box',
        }}
      />

      {status && <p style={{ fontSize: '12px', color: '#555' }}>{status}</p>}

      <div style={{ display: 'grid', gap: '8px' }}>
        {frames.map((f) => (
          <div
            key={f.id}
            style={{ border: '1px solid #ddd', padding: '6px', borderRadius: '4px' }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                marginBottom: '4px',
              }}
            >
              <button onClick={() => handleSeek(f.timestamp)}>
                Jump to {f.formattedTime}
              </button>
              <span style={{ fontSize: '11px', color: '#666' }}>{f.fileName}</span>
            </div>
            <img
              src={f.dataUrl}
              alt={f.formattedTime}
              style={{ width: '100%', borderRadius: '4px' }}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
